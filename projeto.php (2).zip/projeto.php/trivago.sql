-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 25/08/2025 às 20:21
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `trivago`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `clientes`
--

CREATE TABLE `clientes` (
  `clientes_id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telefone` varchar(15) NOT NULL,
  `CPF` char(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `clientes`
--

INSERT INTO `clientes` (`clientes_id`, `nome`, `email`, `telefone`, `CPF`) VALUES
(1, 'João Silva', 'joao@example.com', '11999999999', '12345678901'),
(2, 'Maria Souza', 'maria@example.com', '11888888888', '10987654321'),
(6, 'erick', 'erickRin@exemplo.com', '61888888888', '22222222222'),
(7, 'anakin', 'anakin@gmail.com', '61555555555', '55555555555');

-- --------------------------------------------------------

--
-- Estrutura para tabela `quartos`
--

CREATE TABLE `quartos` (
  `quartos_id` int(11) NOT NULL,
  `TipoDeQuarto` varchar(30) DEFAULT NULL,
  `capacidade` int(11) DEFAULT NULL,
  `preco_por_noite` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `quartos`
--

INSERT INTO `quartos` (`quartos_id`, `TipoDeQuarto`, `capacidade`, `preco_por_noite`) VALUES
(1, 'Solteiro', 1, 150.00),
(2, 'Casal', 2, 250.00),
(3, 'Família', 4, 400.00),
(5, 'cobertura', 8, 2500.00);

-- --------------------------------------------------------

--
-- Estrutura para tabela `reserva`
--

CREATE TABLE `reserva` (
  `id` int(11) NOT NULL,
  `data_entrada` date DEFAULT NULL,
  `data_saida` date DEFAULT NULL,
  `status` enum('pendente','confirmada','cancelada','concluída') DEFAULT 'pendente',
  `cliente_id` int(11) DEFAULT NULL,
  `quarto_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `reserva`
--

INSERT INTO `reserva` (`id`, `data_entrada`, `data_saida`, `status`, `cliente_id`, `quarto_id`) VALUES
(1, '2025-06-01', '2025-06-10', 'confirmada', 1, 1),
(2, '2025-06-03', '2025-06-07', 'confirmada', 2, 2);

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `usuario_id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `senha_hash` varchar(255) NOT NULL,
  `tipo` enum('admin','funcionario') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`usuario_id`, `nome`, `email`, `senha_hash`, `tipo`) VALUES
(12, 'jubileu', 'jubileu@gmail.com', '$2y$10$H3A8tno3MQVFxMIfB.fZg.Cl2b4GA64rCqPBPSrm3Xptp6jhT50PG', 'funcionario'),
(13, 'pedro', 'pedroca@gmail.com', '$2y$10$m0QeBoL3Oa9irqcPv/pHb.6H9zkFU9Qi/Zoktz3gyGFA1w5ieU.1i', 'admin'),
(15, 'lauana', 'lauanaAdm@gmail.com', '$2y$10$AgmacwjVYjNIAFotMhtBEOCQR7UtPizJkdchO92AcZvHAUWInzk7u', 'admin'),
(19, 'zezeDiCamargo', 'zeze@gmail.com', '$2y$10$0ZXysPFrcRL2MzLMyg4ZfeqPa0EXhA2kKEFJPRLqyceECbfR78uLi', 'admin');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`clientes_id`);

--
-- Índices de tabela `quartos`
--
ALTER TABLE `quartos`
  ADD PRIMARY KEY (`quartos_id`);

--
-- Índices de tabela `reserva`
--
ALTER TABLE `reserva`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cliente_id` (`cliente_id`),
  ADD KEY `quarto_id` (`quarto_id`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`usuario_id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `clientes`
--
ALTER TABLE `clientes`
  MODIFY `clientes_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `quartos`
--
ALTER TABLE `quartos`
  MODIFY `quartos_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `reserva`
--
ALTER TABLE `reserva`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `usuario_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `reserva`
--
ALTER TABLE `reserva`
  ADD CONSTRAINT `reserva_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`clientes_id`),
  ADD CONSTRAINT `reserva_ibfk_2` FOREIGN KEY (`quarto_id`) REFERENCES `quartos` (`quartos_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
