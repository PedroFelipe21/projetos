<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
     <form class="formCadastro" method="POST" action="../Controle/ControleCliente.php?ACAO=cadastrarCliente">
       <div class="cadastro">
        
       
       
       <h3>Cadastro</h3><br><br>
          <p>Insira o nome</p>
           <input type="text" name="nomeCliente"><br><br>
           <P>Insira email</P>
           <input type="email" name="emailCliente"><br><br>
           <p>Telefone</p>
           <input type="text" name="telefone"><br><br>
           <p>Informe CPF</p>
           <input type="cpf" name="cpf"><br><br>
           
           <button type= "submit" class="finalizar">finalizar</button>



       </div>


    </form>
</body>
</html>