<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <link rel="stylesheet" href="cadastro.css">
    <title>Document</title>
</head>
<body>
    <form class="formCadastro" method="POST" action="../Controle/ControleUsuario.php?ACAO=cadastrarUsuario">
       <div class="cadastro">
        
       
       
       <h3>Cadastro</h3><br><br>
          <p>Insira o nome</p>
           <input type="text" name="nomeUser"><br><br>
           <P>Insira email</P>
           <input type="email" name="emailUser"><br><br>
           <p>Tipo</p>
           <input type="text" name="tipoUser"><br><br>
           <p>Informe senha</p>
           <input type="password" name="senhaUser"><br><br>
           
           <button type= "submit" class="finalizar">finalizar</button>



       </div>


    </form>
</body>
</html>