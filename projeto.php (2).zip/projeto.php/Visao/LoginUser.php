<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <link rel="stylesheet" href="loginUser.css">
    <title>Document</title>
</head>
<body>
    <form class= "formLogin" action="../Controle/ControleLogin.php?ACAO=autenticar" method="POST">
     <div class="login"></div>
     <p>Nome</p><br>
    <input type="text" name="nomeUser"><br><br>
    <p>Senha</p><br>
    <input type="password" name="senhaUser" required><br><br>

    <button type="submit"class="cadastrar">Entrar</button>
   <a href="cadastro.php" class="cadastrar">Cadastrar</a>
<a href="listarUser.php" class="cadastrar">Outras ações</a>

    </form>
</body>
</html>