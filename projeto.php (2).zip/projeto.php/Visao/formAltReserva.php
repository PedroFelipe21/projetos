<!DOCTYPE html>
<html>
    <head>
        
        <meta charset="UTF-8">
         <title></title>
    </head>
    <body>
        
            <h1>Formulario de atualização de Alunos</h1>
            <hr>
        
		
        <?php
            require '../Modelo/ClassReserva.php';
            require '../Modelo/DAO/ClassReservaDAO.php';
			$id =@$_GET['idex'];
            $novaReserva = new ClassReserva();
            $reservaDAO = new ClassReservaDAO();
            $novaReserva = $reservaDAO->buscarReserva($id);
        ?>
        <form method="post" action="../Controle/ControleReserva.php?ACAO=alterarReserva" >
           <div>    
        <input type="hidden" name="idex" value="<?php echo $novaReserva->getId(); ?>">
               <p>Data de entrada:</p><input type="date" name="de" size="50" value="<?php echo $novaReserva->getDataEntrada(); ?>" /><br>
                <p>Data de saida:</p><input type="date"  name="ds" size="40" value="<?php echo $novaReserva->getDataSaida(); ?>"/>
               
                <br>
				<button type="submit" value="Alterar">Alterar</button> 
				<button  type="reset" value="Limpar">Limpar</button>
            </div>
        </form>
    </body>
</html>
