<!DOCTYPE html>
<html>
    <head>
        
        <meta charset="UTF-8">
         <title></title>
    </head>
    <body>
        
            <h1>Formulario de atualização de Alunos</h1>
            <hr>
        
		
        <?php
            require '../Modelo/ClassCliente.php';
            require '../Modelo/DAO/ClassClienteDAO.php';
			$id =@$_GET['idex'];
            $novoCliente = new ClassCliente();
            $clienteDAO = new ClassClienteDAO();
            $novoCliente = $clienteDAO->buscarCliente($id);

            
        ?>
        <form method="post" action="../Controle/ControleCliente.php?ACAO=alterarCliente" >
           <div>    
        <input type="hidden" name="idex" value="<?php echo $novoCliente->getClienteId(); ?>">
               <p> Nome:</p><input type="text" name="nomeCliente" size="50" value="<?php echo $novoCliente->getNome(); ?>" /><br>
                <p>Email:</p><input type="email" id="emailCliente" name="emailCliente" size="40" value="<?php echo $novoCliente->getEmail(); ?>"/>
                <br>
				<button type="submit" value="Alterar">Alterar</button> 
				<button  type="reset" value="Limpar">Limpar</button>
            </div>
        </form>
    </body>
</html>
