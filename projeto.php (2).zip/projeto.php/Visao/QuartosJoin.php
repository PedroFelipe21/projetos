<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
     <h2 style="text-align: center;">Verificar Quartos Disponíveis</h2>

    <?php
    if (isset($_POST['de']) && isset($_POST['ds'])) {
        $data_inicio = $_POST['de'];
        $data_fim = $_POST['ds'];

        require_once '../Modelo/DAO/ClassReservaDAO.php';

        $reservaDAO = new ClassReservaDAO();
        $quartos = $reservaDAO->listarComStatus($data_inicio, $data_fim);

        if ($quartos && count($quartos) > 0) {
            echo "<table>";
            echo "<tr>
                    <th>ID do Quarto</th>
                    <th>Tipo de Quarto</th>
                    <th>Capacidade</th>
                    <th>Preço por Noite</th>
                    <th>Status</th>
                  </tr>";

            foreach ($quartos as $quarto) {
                $statusClasse = ($quarto['status_quarto'] == 'Disponível') ? 'disponivel' : 'ocupado';
                echo "<tr>";
                echo "<td>{$quarto['quartos_id']}</td>";
                echo "<td>{$quarto['TipoDeQuarto']}</td>";
                echo "<td>{$quarto['capacidade']}</td>";
                echo "<td>R$ {$quarto['preco_por_noite']}</td>";
                echo "<td class='$statusClasse'>{$quarto['status_quarto']}</td>";
                echo "</tr>";
            }

            echo "</table>";
        } else {
            echo "<p style='text-align:center;'>Nenhum quarto encontrado no período informado.</p>";
        }
    } else {
        echo "<p style='text-align:center; color: red;'>Por favor, selecione a data de entrada e saída no formulário anterior.</p>";
    }
    ?>
</body>
</html>