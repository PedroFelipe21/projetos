<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Adicionar quarto</h1>
    <form action="../Controle/ControleQuarto.php?ACAO=cadastrarQuarto" method="post">
        <p>Tipo de quarto</p>
        <input type="text" name="tdq"><br><br>
        <p>Capacidade</p>
        <input type="number" name="capacidade"><br><br>
        <p>Preço por noite</p>
        <input type="number" name="ppn">
        <button type= "submit" class="finalizar">finalizar</button>
        

        
    </form>
</body>
</html>