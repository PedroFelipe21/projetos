<!DOCTYPE html>
<html>
    <head>
        
        <meta charset="UTF-8">
         <title></title>
    </head>
    <body>
        
            <h1>Formulario de atualização de Alunos</h1>
            <hr>
        
		
        <?php
            require '../Modelo/ClassQuarto.php';
            require '../Modelo/DAO/ClassQuartoDAO.php';
			$id =@$_GET['idex'];
            $novoQuarto = new ClassQuarto();
            $quartoDAO = new ClassQuartoDAO();
            $novoQuarto = $quartoDAO->buscarQuarto($id);

            
        ?>
        <form method="post" action="../Controle/ControleQuarto.php?ACAO=alterarQuarto" >
           <div>    
        <input type="hidden" name="idex" value="<?php echo $novoQuarto->getQuartoId(); ?>">
               <p> Tipo de quarto:</p><input type="text" name="tdq" size="50" value="<?php echo $novoQuarto->getTipoDeQuarto(); ?>" /><br>
                <p> Capacidade:</p><input type="number" id="capacidade" name="capacidade" size="40" value="<?php echo $novoQuarto->getCapacidade(); ?>"/>
                <p> Capacidade:</p><input type="number" id="ppn" name="ppn" size="40" value="<?php echo $novoQuarto->getPrecoPorNoite(); ?>"/>
                <br>
				<button type="submit" value="Alterar">Alterar</button> 
				<button  type="reset" value="Limpar">Limpar</button>
            </div>
        </form>
    </body>
</html>
