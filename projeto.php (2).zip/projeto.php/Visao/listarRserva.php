<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Visao/css/form.css">
    <title>Document</title>
    <script language="javaScript" type="text/javascript">
function checkDelete(){
    return confirm('Deseja continuar?');
}
</script>
</head>
<body>
    
<?php
    require '../Modelo/ClassReserva.php';
    require '../Modelo/DAO/ClassReservaDAO.php';

    $classReservaDAO = new ClassReservaDAO();
    $us = $classReservaDAO->listarReserva();
    echo "<div id='direita'>";
    echo "<table class='table'>";
    echo "  <tr>";
    echo "      <th scope='col'><p align='center'>Data de entrada</p></th> ";
    echo "      <th scope='col'><p align='center'>Data de saida</p></th> ";
    echo "      <th scope='col'><p align='center'>status</p></th> ";
     echo "      <th scope='col'><p align='center'>quarto</p></th> ";
    echo "      <th scope='col'><p align='center'>Exluir</p></th> ";
    echo "      <th scope='col'><p align='center'>Alterar</p></th>";
    echo "  <tr>";

    foreach ($us as $us) {
        echo "<tr>";
        echo "<td scope='col'><p align='center'>" . $us['data_entrada'] . "</p></td>";
        echo "<td scope='col'><p align='center'>" . $us['data_saida'] . "</p></td>";
        echo "<td scope='col'><p align='center'>" . $us['status'] . "</p></td>";
         echo "<td scope='col'><p align='center'>" . $us['quarto_id'] . "</p></td>";

        echo "<td scope='col'><a href='../Controle/ControleReserva.php?ACAO=excluirReserva&idex=".$us["id"]."' onclick='return checkDelete()'><input type='button' name='excluir' id='excluir' value='excluir' class='btn btn-danger'></a></td>";
        echo "<td scope='col'><a href='formAltReserva.php?idex=" . $us["id"] . "'><input type='button' value='alterar' class='btn btn-warning'></a></td>";
        echo "</tr>"; 
    }
    echo "</table>";
    echo "<div>";  
    ?>
</body>
</html>





