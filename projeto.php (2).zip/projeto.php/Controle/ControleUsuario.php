<?php

   require_once '../Modelo/ClassUsuario.php';
   require_once '../Modelo/DAO/ClassUsuarioDao.php';

   $id = @$_POST['idex'];
   $nome = @$_POST['nomeUser'];
   $email = @$_POST ['emailUser'];
   $senha = @$_POST['senhaUser'];
   $tipo = @$_POST['tipoUser'];
    $acao = isset($_GET['ACAO']) ? $_GET['ACAO'] : '';




   $novoUsuario = new ClassUsuario();
   $novoUsuario->setUsuarioId($id);
   $novoUsuario->setNomeUsuario($nome);
   $novoUsuario->setEmailUsuario($email);
   $novoUsuario->setSenha($senha);
   $novoUsuario->setTipo($tipo);
  
   

   $ClassUsuarioDAO = new ClassUsuarioDAO();
     switch($acao){
        case "cadastrarUsuario":
            $usuario = $ClassUsuarioDAO->cadastrarUsuario($novoUsuario);
           if($usuario >=1){
          header('Location:../Visao/LoginUser.php?&MSG=Cadastro REALIZADO!');
           }else{
               header('Location:../Visao/cadastro.php?&MSG= Não foi possivel realizar o cadastro!');
           }
        break;

        case "alterarUsuario":
            var_dump($_POST);
            $usuario = $ClassUsuarioDAO->alterarUsuario($novoUsuario);
            if($usuario ==1){
              header('Location:../Visao/listarUser.php?&MSG= mudança realizada!');
            }else{
            header('Location:../formAltUsuario.php?&MSG= Não foi possivel realizar a atualização!');
            }
            break;

        case "excluirUsuario":
            if (isset($_GET['idex'])) {
            $usuarioId = $_GET['idex'];
            $classUsuarioDAO = new ClassUsuarioDAO();
            $us = $classUsuarioDAO->excluirUsuario($usuarioId);
            if ($us == TRUE) {
                header('Location:../Visao/listarUser.php?PAGINA=listarUser&MSG= Usuario foi excluido com sucesso!');
            } else {
                header('Location:../Visao/LoginUser.php?PAGINA=listarUser&MSG=Não foi possivel realizar a exclusão do Usurio!');
            }
        }

        break;
    default :
        break; 
     }

?>