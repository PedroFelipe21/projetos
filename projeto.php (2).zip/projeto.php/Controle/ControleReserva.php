<?php
session_start();
   require_once '../Modelo/ClassReserva.php';
   require_once '../Modelo/DAO/ClassReservaDao.php';

   $clienteId = $_SESSION['clienteS']['clientes_id'];
   $id = @$_POST['idex'];
   $dataEntrada = @$_POST['de'];
   $dataSaida = @$_POST ['ds'];
   $quartoId = @$_POST['quarto_id'];
$status = $_POST['status'] ?? 'pendente';
    $acao = isset($_GET['ACAO']) ? $_GET['ACAO'] : '';

   

   $novaReserva = new ClassReserva();
   $novaReserva->setId($id);
   $novaReserva->setDataEntrada($dataEntrada);
   $novaReserva->setDataSaida($dataSaida);
   $novaReserva->setStatus($status);
   $novaReserva->setClienteId($_SESSION['clienteS']['clientes_id']);
  $novaReserva->setQuartoId($quartoId);
  var_dump($novaReserva);

   $ClassReservaDAO = new ClassReservaDAO();
     switch($acao){
        case "cadastrarReserva":
            $reserva = $ClassReservaDAO->cadastrarReserva($novaReserva);
           if($reserva >=1){
             header("Location: ../Visao/PaginaPrincipal.php&MSG=Cadastro realizado!");
              
           }else{
             header("Location: ../Visao/cadastroReserva.php&MSG=NÃO FOI POSSIVEL REALIZAR O CADASTRO");
           }
        break;

        case "alterarReserva":
            $reserva = $ClassReservaDAO->alterarReserva($novaReserva);
            if($reserva ==1){
                header("Location: ../Visao/listarRserva.php&MSG=Mudanca Realizada!");
            }else{
                header("Location: ../Visao/listarRserva.php&MSG=Mudanca não Realizada!");
            }
            break;

        case "excluirReserva":
            if (isset($_GET['idex'])) {
            $Id = $_GET['idex'];
            $classReservaDAO = new ClassReservaDAO();
            $us = $classReservaDAO->excluirReserva($Id);
            if ($us == TRUE) {
                header("Location: ../Visao/listarRserva.php&MSG=Excluido com suscesso!");
            } else {
                header("Location: ../Visao/listarRserva.php&MSG=Não foi posivel apagar!");
            }
        }

        break;
    default :
        break; 
     }

?>