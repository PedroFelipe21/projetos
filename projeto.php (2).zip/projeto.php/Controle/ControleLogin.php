<?php
session_start();
require_once '../modelo/ClassUsuario.php';
require_once '../Modelo/DAO/ClassUsuarioDAO.php';

$acao = isset($_GET['ACAO']) ? $_GET['ACAO'] : '';

if ($acao == 'autenticar') {

    $usuario = new ClassUsuario($_POST['nomeUser'], $_POST['senhaUser']);
    


    $usuarioDAO = new ClassUsuarioDAO();

    $dados = $usuarioDAO->autenticar($usuario);
    if ($dados) {
        $_SESSION['nomeUser'] = $dados['nome'];
        header('Location: ../Visao/paginaPrincipal.php');
        exit();
    } else {
        $_SESSION['nao_autenticado'] = true;
        header('Location: ../Visao/index.php');
        exit();
    }
}
