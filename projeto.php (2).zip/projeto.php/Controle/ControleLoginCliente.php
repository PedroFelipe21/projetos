<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once '../modelo/ClassCliente.php';
require_once '../Modelo/DAO/ClassClienteDAO.php';



if (isset($_GET['ACAO']) && $_GET['ACAO'] == 'autenticarCliente') {
    $nome = $_POST['nome'] ?? '';
    $email = $_POST['email'] ?? '';
var_dump($nome, $email); // debug
 $cliente = new ClassCliente();         
    $cliente->setNome($nome);              
    $cliente->setEmail($email);
    $clienteDAO = new ClassClienteDAO();
    $resultado = $clienteDAO->autenticarCliente($cliente);
 
    var_dump($resultado); // debug
    if ($resultado) {
        // Login bem-sucedido
        session_start();
        $_SESSION['clienteS'] = $resultado;
        header('Location: ../Visao/PaginaPrincipal.php'); // redireciona para a área do cliente
        exit();
    } else {
        header('Location: ../Visao/deuruim.php'); 
        exit();
    }
}
