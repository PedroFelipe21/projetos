<?php
   require_once '../Modelo/ClassCliente.php';
   require_once '../Modelo/DAO/ClassClienteDao.php';

   $id = @$_POST['idex'];
   $nome = @$_POST['nomeCliente'];
   $email = @$_POST ['emailCliente'];
   $telefone = @$_POST['telefone'];
   $cpf = @$_POST['cpf'];
   
    $acao = isset($_GET['ACAO']) ? $_GET['ACAO'] : '';


   $novoCliente = new ClassCliente();
   $novoCliente->setClienteId($id);
   $novoCliente->setNome($nome);
   $novoCliente->setEmail($email);
   $novoCliente->setTelefone($telefone);
   $novoCliente->setCpf($cpf);
  
   $ClassClienteDAO = new ClassClienteDAO();
     switch($acao){
        case "cadastrarCliente":
            $cliente = $ClassClienteDAO->cadastrarCliente($novoCliente);
           if($cliente >=1){
               header('Location:../Visao/LoginCliente.php?&MSG=Cadastro REALIZADO!');
           }else{
                 header('Location:../Visao/cadastroCliente.php?&MSG=Falhou!');
           }
        break;

        case "alterarCliente":
            $usuario = $ClassClienteDAO->alterarCliente($novoCliente);
            if($usuario ==1){
                 header('Location:../Visao/listarCliente.php?&MSG= mudança realizada!');
            }else{
                 header('Location:../formAltCliente.php?&MSG= Não foi possivel realizar a atualização!');
            }
            break;

        case "excluirCliente":
           if ($acao == 'excluirCliente') {
    $id = $_GET['idex'];
    if (ClassClienteDAO::excluirCliente($id)) {
        header("Location: ../Visao/listarCliente.php");
        exit();
    } else {
        echo "Erro ao excluir cliente.";
    }
}

        break;
    default :
        break; 
     }

?>