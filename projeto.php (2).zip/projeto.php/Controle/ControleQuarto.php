<?php
require_once '../modelo/ClassQuarto.php';
require_once '../modelo/DAO/ClassQuartoDAO.php';

$idQuarto = @$_POST['idex'];
$tipoDeQuarto = @$_POST['tdq'];
$capacidade = @$_POST['capacidade'];
$precoPorNoite = @$_POST['ppn'];

    $acao = isset($_GET['ACAO']) ? $_GET['ACAO'] : '';

$novoQuarto = new ClassQuarto();
$novoQuarto->setQuartoId($idQuarto);
$novoQuarto->setTipoDeQuarto($tipoDeQuarto);
$novoQuarto->setCapacidade($capacidade);
$novoQuarto->setPrecoPorNoite($precoPorNoite);

$quartoDAO = new ClassQuartoDAO();

switch($acao){
    case "cadastrarQuarto":
         $quarto = $quartoDAO->cadastrarQuarto($novoQuarto);
           if($quarto >=1){
             header('Location:../Visao/PaginaPrincipal.php?&MSG=Cadastro REALIZADO!');
           }else{
header('Location:../Visao/PaginaPrincipal.php?&MSG=Cadastro REALIZADO!');
           }
        break;
    case "alterarQuarto":
        $quarto = $quartoDAO->alterarQuarto($novoQuarto);
        if($quarto==1){
            header('Location:../Visao/listarQuarto.php?&MSG= mudança realizada!');
        }else{
            header('Location:../formAltQuarto.php?&MSG= Não foi possivel realizar a atualização!');
        }
        break;
    case "excluirQuarto":
          if (isset($_GET['idex'])) {
            $idQuarto = $_GET['idex'];
            $classQuartoDAO = new ClassQuartoDAO();
            $us = $classQuartoDAO->excluirQuarto($idQuarto);
            if ($us == TRUE) {
                header("Location: ../Visao/listarQuarto.php");
            } else {
                echo('Não foi possivel excluir quarto!');
            }
        }
      break;
      default :
      break;
}
?>