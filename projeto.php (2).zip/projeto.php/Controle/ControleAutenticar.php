<?php
session_start();
if (!isset($_SESSION['nomeUser'])) {
    header('Location: ../Visao/index.php');
    exit();
}
?>
