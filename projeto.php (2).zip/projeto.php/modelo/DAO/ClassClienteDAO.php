<?php
require_once 'Conexao.php';
 
Class ClassClienteDAO{
  //cadstro
public static function cadastrarCliente(ClassCliente $cadCliente){
   
    try{
        $pdo = Conexao::getInstance();
        $sql = 'INSERT INTO clientes (nome, email, telefone, CPF) values (?,?,?,?)';
          $stmt = $pdo->prepare($sql);
            $stmt->bindValue(1, $cadCliente->getNome());
            $stmt->bindValue(2, $cadCliente->getEmail());
            $stmt->bindValue(3,$cadCliente->getTelefone());
            $stmt->bindValue(4,$cadCliente->getCpf());
            if ($stmt->execute()) {
            return true;
        } else {
            print_r($stmt->errorInfo());
            return false;
        }
    }catch(PDOException $exc){
        echo $exc->getMessage();
    }
}

 //listar
 public static function listarCliente(){
   try{
        $pdo = Conexao::getInstance();
            $sql = "SELECT * FROM clientes order by (nome) asc";
            $stmt = $pdo->prepare($sql);
            $stmt->execute();
            $cliente = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $cliente;
   }catch(PDOException $exc){
    echo $exc->getMessage();
   }
 }

 //excluir

 public static function excluirCliente($clienteId){
    
    try{ 
    $pdo = Conexao::getInstance();
    $sql = 'DELETE FROM clientes WHERE clientes_id = :clientes_id';
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':clientes_id', $clienteId);
            $stmt->execute();
            return TRUE;
      }catch(PDOException $exc){
           echo $exc->getMessage();
      }

      

 }
//alterar

      public static function alterarCliente(ClassCliente $alterarCliente){
        try{
            $pdo = Conexao::getInstance();
            $sql = 'UPDATE clientes SET nome=?, email=? WHERE clientes_id = ? ';
             $stmt = $pdo->prepare($sql);
             $stmt->bindValue(1,$alterarCliente->getNome());
             $stmt->bindValue(2,$alterarCliente->getEmail());
             $stmt->bindValue(3,$alterarCliente->getClienteId());
             $stmt->execute();
             return true;
        }catch(PDOException $exc){
            echo $exc->getMessage();
        }



      }



      public function autenticarCliente( $cliente) {
 try{   $pdo = Conexao::getInstance();
    $sql = "SELECT * FROM clientes WHERE nome = :nome AND email = :email LIMIT 1";
    $stmt = $pdo->prepare($sql);
     $stmt->bindValue(':nome', $cliente->getNome());
        $stmt->bindValue(':email', $cliente->getEmail());
    $stmt->execute();
    $resultado = $stmt->fetch(PDO::FETCH_ASSOC);

     if ($resultado) {
            return $resultado;
        }

        return false;
    } catch (PDOException $e) {
        echo "Erro ao autenticar cliente: " . $e->getMessage();
        return false;
    }
}

public function buscarCliente($idCliente)
    {
        try {
            $cliente = new ClassCliente();
            $pdo = Conexao::getInstance();
            $sql = "SELECT clientes_id, nome, email FROM clientes WHERE clientes_id = :id LIMIT 1";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':id', $idCliente);
            
            $stmt->execute();
            $clienteAssoc = $stmt->fetch(PDO::FETCH_ASSOC);

           $cliente->setClienteId($clienteAssoc['clientes_id']);

            $cliente->setNome($clienteAssoc['nome']);
            $cliente->setEmail($clienteAssoc['email']);
           
            return $cliente;
        } catch (PDOException $ex) {
            return $ex->getMessage();
        }
    }
}








?>