<?php
require_once 'Conexao.php';
 
Class ClassReservaDAO{
  //cadstro
public static function cadastrarReserva(ClassReserva $cadReserva){
   
    try{
        $pdo = Conexao::getInstance();
        $sql = 'INSERT INTO reserva (data_entrada, data_saida,`status`,cliente_id,quarto_id) values (?,?,?,?,?)';
          $stmt = $pdo->prepare($sql);
            $stmt->bindValue(1, $cadReserva->getDataEntrada());
            $stmt->bindValue(2, $cadReserva->getDataSaida());
            $stmt->bindValue(3, $cadReserva->getStatus());
            $stmt->bindValue(4, $cadReserva->getClienteId());
            $stmt->bindValue(5, $cadReserva->getQuartoId());

            if ($stmt->execute()) {
            return true;
        } else {
            
            print_r($stmt->errorInfo());
            return false;
        }
    }catch(PDOException $exc){
        echo $exc->getMessage();
    }
}

 //listar
 public static function listarReserva(){
   try{
        $pdo = Conexao::getInstance();
            $sql = "SELECT * FROM reserva order by (data_saida) asc";
            $stmt = $pdo->prepare($sql);
            $stmt->execute();
            $cliente = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $cliente;
   }catch(PDOException $exc){
    echo $exc->getMessage();
   }
 }

 //excluir

 public static function excluirReserva($Id){
    
    try{ 
    $pdo = Conexao::getInstance();
    $sql = 'DELETE FROM reserva WHERE id = :id';
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':id', $Id);
            $stmt->execute();
            return TRUE;
      }catch(PDOException $exc){
           echo $exc->getMessage();
      }

      

 }
//alterar

      public static function alterarReserva(ClassReserva $alterarReserva){
        try{
            $pdo = Conexao::getInstance();
            $sql = 'UPDATE reserva SET data_entrada=?, data_saida=? WHERE id = ? ';
             $stmt = $pdo->prepare($sql);
             $stmt->bindValue(1,$alterarReserva->getDataEntrada());
             $stmt->bindValue(2,$alterarReserva->getDataSaida());
               $stmt->bindValue(3, $alterarReserva->getId());
             
             $stmt->execute();
             return true;
        }catch(PDOException $exc){
            echo $exc->getMessage();
        }



      }
      public function buscarReserva($id)
    {
        try {
            $reserva = new ClassReserva();
            $pdo = Conexao::getInstance();
            $sql = "SELECT id, data_entrada, data_saida FROM reserva WHERE id = :id LIMIT 1";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':id', $id);
            var_dump($id);
            $stmt->execute();
            $usuarioAssoc = $stmt->fetch(PDO::FETCH_ASSOC);

            $reserva->setId($usuarioAssoc['id']);
            $reserva->setDataEntrada($usuarioAssoc['data_entrada']);
            $reserva->setDataSaida($usuarioAssoc['data_saida']);

            return $reserva;
        } catch (PDOException $ex) {
            return $ex->getMessage();
        }
    }

     public function listarComStatus($data_inicio, $data_fim) {
        $sql = "
            SELECT 
                q.quartos_id,
                q.TipoDeQuarto,
                q.capacidade,
                q.preco_por_noite,
                r.data_entrada,
                r.data_saida,
                r.status AS status_reserva,
                CASE
                    WHEN r.quarto_id IS NOT NULL 
                         AND r.status = 'confirmada'
                         AND r.data_entrada <= :data_fim
                         AND r.data_saida >= :data_inicio
                    THEN 'Ocupado'
                    ELSE 'Disponível'
                END AS status_quarto
            FROM quartos q
            LEFT JOIN reserva r ON q.quartos_id = r.quarto_id 
                                  
                                  AND r.data_entrada <= :data_fim
                                  AND r.data_saida >= :data_inicio
            ORDER BY q.quartos_id
        ";
        $pdo = Conexao::getInstance();
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':data_inicio', $data_inicio);
        $stmt->bindValue(':data_fim', $data_fim);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}








?>