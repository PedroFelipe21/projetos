<?php
require_once 'Conexao.php';
 
Class ClassUsuarioDAO{
  //cadstro
public static function cadastrarUsuario(ClassUsuario $cadUser){
   
    try{
        $pdo = Conexao::getInstance();
        $sql = 'INSERT INTO usuarios (nome, email, senha_hash, tipo) values (?,?,?,?)';
          $stmt = $pdo->prepare($sql);
         

          $stmt->bindValue(1, $cadUser->getNomeUsuario());
            $stmt->bindValue(2, $cadUser->getEmailUsuario());
            $stmt->bindValue(3, password_hash($cadUser->getSenha(), PASSWORD_DEFAULT));
            $stmt->bindValue(4, $cadUser->getTipo());
            $stmt->execute();
            if ($stmt->execute()) {
            return true;
        } else {
            
            print_r($stmt->errorInfo());
            return false;
        }

    }catch(PDOException $exc){
        echo $exc->getMessage();
        return 0;
    }
}

 //listar
 public static function listarUsuario(){
   try{
        $pdo = Conexao::getInstance();
            $sql = "SELECT * FROM usuarios order by (nome) asc";
            $stmt = $pdo->prepare($sql);
            $stmt->execute();
            $usuario = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $usuario;
   }catch(PDOException $exc){
    echo $exc->getMessage();
   }
 }

 //excluir

 public static function excluirUsuario($usuarioId){
    
    try{ 
    $pdo = Conexao::getInstance();
    $sql = 'DELETE FROM usuarios WHERE usuario_id = :usuario_id';
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':usuario_id', $usuarioId);
            $stmt->execute();
            return TRUE;
      }catch(PDOException $exc){
           echo $exc->getMessage();
      }

      

 }
//alterar

      public static function alterarUsuario(ClassUsuario $alterarUsuario){
        try{
            $pdo = Conexao::getInstance();
            $sql = 'UPDATE usuarios SET nome=?, email=? WHERE usuario_id = ? ';
             $stmt = $pdo->prepare($sql);
             $stmt->bindValue(1,$alterarUsuario->getNomeUsuario());
             $stmt->bindValue(2,$alterarUsuario->getEmailUsuario());
             $stmt->bindValue(3,$alterarUsuario->getUsuarioId());
             $stmt->execute();
             return true;
        }catch(PDOException $exc){
            echo $exc->getMessage();
        }
      }
    

public function autenticar($usuario) {
    $pdo = Conexao::getInstance();
    $sql = "SELECT * FROM usuarios WHERE nome = :nome"; 
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(":nome", $usuario->getNomeUsuario());
    $stmt->execute();
    $resultado = $stmt->fetch(PDO::FETCH_ASSOC);

    var_dump($resultado); // debug

    if ($resultado) {
        var_dump(password_verify($usuario->getSenha(), $resultado['senha_hash'])); // debug
    }

    if ($resultado && password_verify($usuario->getSenha(), $resultado['senha_hash'])) {
        return $resultado;
    }

    return false;
}

public function buscarUsuario($idUsuario)
    {
        try {
            $usuario = new ClassUsuario();
            $pdo = Conexao::getInstance();
            $sql = "SELECT usuario_id, nome, email FROM usuarios WHERE usuario_id =:id LIMIT 1";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':id', $idUsuario);
            var_dump($idUsuario);
            $stmt->execute();
            $usuarioAssoc = $stmt->fetch(PDO::FETCH_ASSOC);

            $usuario->setUsuarioId($usuarioAssoc['usuario_id']);
            $usuario->setNomeUsuario($usuarioAssoc['nome']);
            $usuario->setEmailUsuario($usuarioAssoc['email']);

            return $usuario;
        } catch (PDOException $ex) {
            return $ex->getMessage();
        }
    }





}








?>