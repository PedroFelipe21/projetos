<?php
require_once 'Conexao.php';

Class ClassQuartoDao{
  public static function cadastrarQuarto(ClassQuarto $cadQuarto){
   
    try{
        $pdo = Conexao::getInstance();
        $sql = 'INSERT INTO quartos (TipoDeQuarto, capacidade, preco_por_noite) values (?,?,?)';
          $stmt = $pdo->prepare($sql);
            $stmt->bindValue(1, $cadQuarto->getTipoDeQuarto());
            $stmt->bindValue(2, $cadQuarto->getCapacidade());
            $stmt->bindValue(3,$cadQuarto->getPrecoPorNoite());
            if ($stmt->execute()) {
            return true;
        } else {
            
            print_r($stmt->errorInfo());
            return false;
        }
    }catch(PDOException $exc){
        echo $exc->getMessage();
    }
}

public static function listarQuarto(){
   try{
        $pdo = Conexao::getInstance();
            $sql = "SELECT * FROM quartos order by preco_por_noite asc";
            $stmt = $pdo->prepare($sql);
            $stmt->execute();
            $quarto = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $quarto;
   }catch(PDOException $exc){
    echo $exc->getMessage();
   }
 }
public static function excluirQuarto($quartoId){
    
    try{ 
    $pdo = Conexao::getInstance();
    $sql = 'DELETE FROM quartos WHERE quartos_id = :quartos_id';
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':quartos_id', $quartoId);
            $stmt->execute();
            return TRUE;
      }catch(PDOException $exc){
           echo $exc->getMessage();
      }
    }

     public static function alterarQuarto(ClassQuarto $alterarQuarto){
        try{
            $pdo = Conexao::getInstance();
            $sql = 'UPDATE quartos SET tipoDeQuarto=?, capacidade=?, preco_por_noite=? WHERE quartos_id = ? ';
             $stmt = $pdo->prepare($sql);
             $stmt->bindValue(1,$alterarQuarto->getTipoDeQuarto());
             $stmt->bindValue(2,$alterarQuarto->getCapacidade());
             $stmt->bindValue(3,$alterarQuarto->getPrecoPorNoite());
             $stmt->bindValue(4,$alterarQuarto->getQuartoId());
             $stmt->execute();
             return true;
        }catch(PDOException $exc){
            echo $exc->getMessage();
        }



      }

      public function buscarQuarto($idQuarto)
    {
        try {
            $quarto = new ClassQuarto();
            $pdo = Conexao::getInstance();
            $sql = "SELECT quartos_id, TipoDeQuarto, capacidade,preco_por_noite FROM quartos WHERE quartos_id =:id LIMIT 1";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':id', $idQuarto);
            var_dump($idQuarto);
            $stmt->execute();
            $usuarioAssoc = $stmt->fetch(PDO::FETCH_ASSOC);

            $quarto->setQuartoId($usuarioAssoc['quartos_id']);
            $quarto->setTipoDeQuarto($usuarioAssoc['TipoDeQuarto']);
            $quarto->setCapacidade($usuarioAssoc['capacidade']);
            $quarto->setPrecoPorNoite($usuarioAssoc['preco_por_noite']);
            return $quarto;
        } catch (PDOException $ex) {
            return $ex->getMessage();
        }
    }
     
}

?>