
package projetooo;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.Scanner;

public class ProjetoOO {
private Connection con;
 private Statement stmt;
   
public ProjetoOO(){
try{
 Class.forName("com.mysql.cj.jdbc.Driver");
 System.out.println("OLA!");
 } catch(ClassNotFoundException e){
 System.out.println("deu ruim!" +
e);
 System.out.println("Error: "+ e.getMessage());
 }
String url = "jdbc:mysql://localhost:3306/bancojava";
 String user = "root";
 String password = "";
try{

con=DriverManager.getConnection(url,user,password);
stmt = con.createStatement();

}catch(SQLException e){
 System.out.println("Error: "+ e.getMessage());
}
}

//listar aluno

private void listarRegistros(){

try{
 ResultSet rs;
 rs = stmt.executeQuery("SELECT * FROM alunos");
while ( rs.next() ) {
String nome = rs.getString("nome_aluno");
String email = rs.getString("email");
String aniversario = rs.getString("data_nascimente");
    System.out.println(nome +"\n" + email + "\n" + aniversario +"\n");
}
 }catch(SQLException e){
 System.out.println("Erro: "+ e.getMessage());
 }
 }

 //listar curso

private void listarRegistrosCurso(){

try{
 ResultSet rs;
 rs = stmt.executeQuery("SELECT * FROM turma");
while ( rs.next() ) {
String nomeTurma = rs.getString("nome_turna");
String horario = rs.getString("horario");
int vagasTotais = rs.getInt("vagasTotais");
int vagasPreenchidas = rs.getInt("VagasPreenchidas");
    System.out.println(nomeTurma +"\n"+horario+"\n"+vagasTotais+"\n"+vagasPreenchidas);

}
 }catch(SQLException e){
 System.out.println("Erro: "+ e.getMessage());
 }
 }

//alterar  aluno
private void alterarRegistros(String nome, int id){
 try{
 stmt.executeUpdate("UPDATE alunos SET nome_aluno = '" + nome+"' WHERE id_aluno=" +id+ "");

 }catch(SQLException e){
 System.out.println("Erro: "+ e.getMessage());
 }
}
//inserir Aluno
private void inserirRegistros(String nome,String email, String aniversario ){ 
        try{
            stmt.executeUpdate(
            "INSERT INTO alunos(nome_aluno, email, data_nascimente) VALUES ('" 
            + nome + "', '" + email + "', '" + aniversario + "')"
        );
        }catch(SQLException e){
            System.out.println("Erro: " + e.getMessage()); 
        }

}
//inserir curso:

private void inserirCurso(String nomeTurma, String horario, int vagasTotais, int vagasPreenchidas) {
    try {
        String sql = "INSERT INTO turma (nome_turna, horario, vagasTotais, vagasPreenchidas) " +
                     "VALUES ('" + nomeTurma + "', '" + horario + "', " + vagasTotais + ", " + vagasPreenchidas + ")";
        stmt.executeUpdate(sql);
        System.out.println("Curso inserido com sucesso!");
    } catch (SQLException e) {
        System.out.println("Erro ao inserir curso: " + e.getMessage());
    }
}

//inserir aluno ao curso:

private void inserirAlunoAoCurso(int idAluno, int idTurma) {
    try {
        String query = "INSERT INTO alunos_curso (id_aluno, id_turma) VALUES (" + idAluno + ", " + idTurma + ")";
        stmt.executeUpdate(query);
        System.out.println("Aluno vinculado ao curso com sucesso!");
    } catch (SQLException e) {
        System.out.println("Erro ao vincular aluno ao curso: " + e.getMessage());
    }
}

//listar curso e aluno:
private void listarAlunosCursos() {
    String sql = "SELECT a.id_aluno, a.nome_aluno, t.id_turma, t.nome_turna " +
                 "FROM alunos_curso ac " +
                 "JOIN alunos a ON ac.id_aluno = a.id_aluno " +
                 "JOIN turma t ON ac.id_turma = t.id_turma";

    try {
        ResultSet rs = stmt.executeQuery(sql);

        System.out.println("\n--- Alunos Matriculados em Cursos ---");
        while (rs.next()) {
            int idAluno = rs.getInt("id_aluno");
            String nomeAluno = rs.getString("nome_aluno");
            int idTurma = rs.getInt("id_turma");
            String nomeTurna = rs.getString("nome_turna");

            System.out.println("Aluno: " + nomeAluno + " (ID: " + idAluno + ")");
            System.out.println("Curso: " + nomeTurna + " (ID: " + idTurma + ")");
            System.out.println("-----------------------------");
        }

    } catch (SQLException e) {
        System.out.println("Erro ao listar alunos e cursos: " + e.getMessage());
    }
}

//apagar aluno

private void apagarRegistros(int id){ 
        try{ 
        stmt.executeUpdate("DELETE FROM alunos WHERE id_aluno="+id+" ");
        }catch(SQLException e){ 
            System.out.println("Erro: "+ e.getMessage()); 
        }   
}

public static void main(String[] args) {
    ProjetoOO p = new ProjetoOO(); 
    int opcao =0;
     Scanner input = new Scanner(System.in);
  
    do{
        System.out.println("----BEM VINDO----");
        System.out.println("--QUAL ACAO DESEJA?--");
        System.out.println("1-Insrir aluno");
        System.out.println("2-Alterar aluno");
        System.out.println("3-Excluir aluno");
        System.out.println("4-listar aluno");
        System.out.println("5-inserir aluno ao curso");
        System.out.println("6-listar curso");
        System.out.println("7-listar alunos e cursos");
        System.out.println("8-inserir turma");
        System.out.println("9-Sair");
        opcao = input.nextInt();
        input.nextLine();
        switch(opcao){
            case 1:
                System.out.print("Nome do aluno: ");
                    String nome = input.nextLine();
                    System.out.print("Email do aluno: ");
                    String email = input.nextLine();
                    System.out.print("Data de nascimento (YYYY-MM-DD): ");
                    String aniversario = input.nextLine();
                    p.inserirRegistros(nome, email, aniversario);
                    break;
            case 2:
                System.out.print("ID do aluno a alterar: ");
                    int idAlterar = input.nextInt();
                    input.nextLine();
                    System.out.print("Novo nome: ");
                    String novoNome = input.nextLine();
                    p.alterarRegistros(novoNome, idAlterar);
                    break;
            case 3:
                System.out.println("Informe o ID do aluno: ");
                int id = input.nextInt();
                p.apagarRegistros(id);
                break;
            case 4:
                p.listarRegistros();
                break;
            case 5:
                  System.out.print("ID do aluno: ");
                    int idAluno = input.nextInt();
                    System.out.print("ID do curso: ");
                    int idCurso = input.nextInt();
                    p.inserirAlunoAoCurso(idAluno, idCurso);
                    break;
            case 6:
                p.listarRegistrosCurso();
                    break;
            case 7:
                p.listarAlunosCursos();
                    break;
            case 8:
                System.out.print("Nome da turma: ");
                String nomeTurma = input.nextLine();
                System.out.print("Horário: ");
                String horario = input.nextLine();
                System.out.print("Vagas totais: ");
                int vagasTotais = input.nextInt();
                System.out.print("Vagas preenchidas: ");
                int vagasPreenchidas = input.nextInt();
                input.nextLine(); 
                p.inserirCurso(nomeTurma, horario, vagasTotais, vagasPreenchidas);
        }
    }while(opcao !=9);

    }
    
}

 